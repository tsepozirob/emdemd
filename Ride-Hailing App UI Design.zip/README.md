
  # Ride-Hailing App UI Design

  This is a code bundle for Ride-Hailing App UI Design. The original project is available at https://www.figma.com/design/aHcAsbMVGEI1ZH6iqZIpcE/Ride-Hailing-App-UI-Design.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  