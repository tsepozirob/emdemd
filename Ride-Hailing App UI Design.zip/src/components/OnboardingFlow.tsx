import React, { useState } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { ChevronRight, Car, MapPin, Shield, Chrome, Facebook, Apple } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { ImageWithFallback } from './figma/ImageWithFallback';

interface OnboardingFlowProps {
  onComplete: () => void;
}

const OnboardingFlow: React.FC<OnboardingFlowProps> = ({ onComplete }) => {
  const [currentStep, setCurrentStep] = useState(0);
  const [phoneNumber, setPhoneNumber] = useState('');

  const carouselItems = [
    {
      icon: <Car className="w-16 h-16 text-white" />,
      title: "Find Your Ride",
      description: "Request a ride and get matched with a driver in seconds",
      image: "https://images.unsplash.com/photo-1528033978085-52f315289665?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjB0cmFja2luZyUyMG1vYmlsZSUyMGFwcHxlbnwxfHx8fDE3NTc5NDQyOTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      icon: <MapPin className="w-16 h-16 text-white" />,
      title: "Track in Real-Time",
      description: "Follow your driver's location and get accurate arrival times",
      image: "https://images.unsplash.com/photo-1625217527288-93919c99650a?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxjYXIlMjB0cmFja2luZyUyMG1vYmlsZSUyMGFwcHxlbnwxfHx8fDE3NTc5NDQyOTV8MA&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    },
    {
      icon: <Shield className="w-16 h-16 text-white" />,
      title: "Arrive Safely",
      description: "Travel with confidence using our safety features and driver verification",
      image: "https://images.unsplash.com/photo-1587341433400-a10157e26930?crop=entropy&cs=tinysrgb&fit=max&fm=jpg&ixid=M3w3Nzg4Nzd8MHwxfHNlYXJjaHwxfHxzYWZlJTIwdHJhdmVsJTIwbW9iaWxlJTIwYXBwfGVufDF8fHx8MTc1Nzk0NDI5OHww&ixlib=rb-4.1.0&q=80&w=1080&utm_source=figma&utm_medium=referral"
    }
  ];

  const WelcomeScreen = () => (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -20 }}
      className="flex flex-col items-center justify-center h-full p-8 gradient-shuvr relative overflow-hidden"
    >
      {/* Background glow effects */}
      <div className="absolute top-20 left-10 w-32 h-32 bg-white/10 rounded-full blur-xl"></div>
      <div className="absolute bottom-32 right-10 w-24 h-24 bg-white/10 rounded-full blur-xl"></div>
      
      <motion.div
        initial={{ scale: 0.8, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
        transition={{ delay: 0.2, duration: 0.8 }}
        className="text-center"
      >
        <motion.h1 
          className="text-6xl mb-4 text-white tracking-tight"
          animate={{ 
            textShadow: [
              "0 0 20px rgba(255,255,255,0.5)",
              "0 0 30px rgba(255,255,255,0.8)", 
              "0 0 20px rgba(255,255,255,0.5)"
            ]
          }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          Shuvr
        </motion.h1>
        <motion.p 
          className="text-xl text-white/90 mb-12"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          Move Smarter. Move Freely.
        </motion.p>
        
        <motion.div
          whileHover={{ scale: 1.05 }}
          whileTap={{ scale: 0.95 }}
        >
          <Button
            onClick={() => setCurrentStep(1)}
            className="glass text-white border-white/30 hover:bg-white/20 px-8 py-6 rounded-2xl glow-purple"
          >
            Get Started
            <ChevronRight className="ml-2 w-5 h-5" />
          </Button>
        </motion.div>
      </motion.div>
    </motion.div>
  );

  const CarouselScreen = () => (
    <motion.div
      initial={{ opacity: 0, x: 100 }}
      animate={{ opacity: 1, x: 0 }}
      exit={{ opacity: 0, x: -100 }}
      className="flex flex-col h-full bg-gradient-to-br from-gray-50 to-white"
    >
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        <AnimatePresence mode="wait">
          <motion.div
            key={currentStep - 1}
            initial={{ opacity: 0, y: 50 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0, y: -50 }}
            className="text-center max-w-sm"
          >
            <div className="relative mb-8">
              <ImageWithFallback
                src={carouselItems[currentStep - 1]?.image}
                alt={carouselItems[currentStep - 1]?.title}
                className="w-64 h-64 object-cover rounded-3xl mx-auto shadow-2xl"
              />
              <motion.div
                className="absolute inset-0 flex items-center justify-center"
                initial={{ scale: 0 }}
                animate={{ scale: 1 }}
                transition={{ delay: 0.3 }}
              >
                <div className="glass rounded-full p-6 glow-purple">
                  {carouselItems[currentStep - 1]?.icon}
                </div>
              </motion.div>
            </div>
            
            <h2 className="text-3xl mb-4 gradient-text">
              {carouselItems[currentStep - 1]?.title}
            </h2>
            <p className="text-gray-600 text-lg leading-relaxed">
              {carouselItems[currentStep - 1]?.description}
            </p>
          </motion.div>
        </AnimatePresence>
      </div>

      {/* Dots indicator */}
      <div className="flex justify-center space-x-2 mb-8">
        {carouselItems.map((_, index) => (
          <motion.div
            key={index}
            className={`w-3 h-3 rounded-full transition-all duration-300 ${
              index === currentStep - 1 ? 'gradient-shuvr' : 'bg-gray-300'
            }`}
            whileHover={{ scale: 1.2 }}
          />
        ))}
      </div>

      {/* Navigation */}
      <div className="flex justify-between items-center p-6">
        <Button
          variant="ghost"
          onClick={() => currentStep > 1 ? setCurrentStep(currentStep - 1) : setCurrentStep(0)}
          className="text-gray-500"
        >
          Back
        </Button>
        
        <Button
          onClick={() => currentStep < carouselItems.length ? setCurrentStep(currentStep + 1) : setCurrentStep(4)}
          className="gradient-shuvr text-white px-6 py-3 rounded-xl glow-purple"
        >
          {currentStep < carouselItems.length ? 'Next' : 'Sign Up'}
          <ChevronRight className="ml-2 w-4 h-4" />
        </Button>
      </div>
    </motion.div>
  );

  const SignInScreen = () => (
    <motion.div
      initial={{ opacity: 0, y: 100 }}
      animate={{ opacity: 1, y: 0 }}
      exit={{ opacity: 0, y: -100 }}
      className="flex flex-col h-full bg-white p-8"
    >
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 0.2 }}
        className="flex-1 flex flex-col justify-center max-w-sm mx-auto w-full"
      >
        <h2 className="text-3xl mb-2 text-center gradient-text">Welcome Back</h2>
        <p className="text-gray-600 text-center mb-8">Sign in to continue your journey</p>

        {/* Phone number input */}
        <div className="space-y-4 mb-8">
          <div className="relative">
            <Input
              type="tel"
              placeholder="Enter your phone number"
              value={phoneNumber}
              onChange={(e) => setPhoneNumber(e.target.value)}
              className="w-full px-6 py-4 rounded-xl border-2 border-gray-200 focus:border-[#5C2E91] bg-gray-50 text-lg"
            />
          </div>
          
          <motion.div whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
            <Button
              onClick={onComplete}
              className="w-full gradient-shuvr text-white py-4 rounded-xl glow-purple"
            >
              Continue with Phone
            </Button>
          </motion.div>
        </div>

        {/* Divider */}
        <div className="flex items-center my-6">
          <div className="flex-1 h-px bg-gray-200"></div>
          <span className="px-4 text-gray-500">or</span>
          <div className="flex-1 h-px bg-gray-200"></div>
        </div>

        {/* Social sign-in options */}
        <div className="space-y-3">
          {[
            { icon: <Chrome className="w-5 h-5" />, label: "Continue with Google", color: "bg-red-500" },
            { icon: <Facebook className="w-5 h-5" />, label: "Continue with Facebook", color: "bg-blue-600" },
            { icon: <Apple className="w-5 h-5" />, label: "Continue with Apple", color: "bg-black" }
          ].map((option, index) => (
            <motion.div key={option.label} whileHover={{ scale: 1.02 }} whileTap={{ scale: 0.98 }}>
              <Button
                variant="outline"
                onClick={onComplete}
                className="w-full py-4 rounded-xl border-2 border-gray-200 hover:border-gray-300 flex items-center justify-center space-x-3"
              >
                <div className={`${option.color} text-white p-1 rounded`}>
                  {option.icon}
                </div>
                <span>{option.label}</span>
              </Button>
            </motion.div>
          ))}
        </div>
      </motion.div>

      <Button
        variant="ghost"
        onClick={() => setCurrentStep(1)}
        className="text-gray-500 mt-4"
      >
        Back to carousel
      </Button>
    </motion.div>
  );

  return (
    <div className="h-screen overflow-hidden">
      <AnimatePresence mode="wait">
        {currentStep === 0 && <WelcomeScreen />}
        {currentStep >= 1 && currentStep <= 3 && <CarouselScreen />}
        {currentStep === 4 && <SignInScreen />}
      </AnimatePresence>
    </div>
  );
};

export default OnboardingFlow;