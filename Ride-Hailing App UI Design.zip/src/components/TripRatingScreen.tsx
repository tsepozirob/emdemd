import React, { useState } from 'react';
import { motion } from 'motion/react';
import { Star, ThumbsUp, MessageCircle, DollarSign, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Textarea } from './ui/textarea';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';

interface TripRatingScreenProps {
  driver: any;
  tripDetails: {
    pickup: string;
    destination: string;
    fare: string;
    duration: string;
    distance: string;
  };
  onComplete: () => void;
  onSkip: () => void;
}

const TripRatingScreen: React.FC<TripRatingScreenProps> = ({
  driver,
  tripDetails,
  onComplete,
  onSkip
}) => {
  const [rating, setRating] = useState(0);
  const [feedback, setFeedback] = useState('');
  const [selectedTags, setSelectedTags] = useState<string[]>([]);
  const [tip, setTip] = useState('');

  const feedbackTags = [
    'Great conversation',
    'Clean car',
    'Safe driving',
    'On time',
    'Friendly',
    'Smooth ride',
    'Good music',
    'Professional'
  ];

  const tipOptions = ['$1', '$2', '$3', '$5'];

  const handleTagToggle = (tag: string) => {
    setSelectedTags(prev => 
      prev.includes(tag) 
        ? prev.filter(t => t !== tag)
        : [...prev, tag]
    );
  };

  const handleSubmit = () => {
    // In a real app, this would submit the rating to the backend
    console.log({
      driverId: driver.id,
      rating,
      feedback,
      tags: selectedTags,
      tip
    });
    onComplete();
  };

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex items-center justify-between p-4 border-b border-gray-100"
      >
        <Button variant="ghost" onClick={onSkip} className="text-gray-500">
          Skip
        </Button>
        <h1 className="text-lg gradient-text">Rate Your Trip</h1>
        <div className="w-16"></div>
      </motion.div>

      <div className="flex-1 overflow-y-auto p-6 space-y-6">
        {/* Trip Summary */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="p-6 gradient-shuvr text-white rounded-2xl">
            <div className="text-center mb-4">
              <h2 className="text-xl mb-1">Trip Completed!</h2>
              <p className="text-white/80">You arrived safely at your destination</p>
            </div>
            
            <div className="grid grid-cols-3 gap-4 text-center">
              <div>
                <p className="text-2xl font-medium">{tripDetails.duration}</p>
                <p className="text-white/80 text-sm">Duration</p>
              </div>
              <div>
                <p className="text-2xl font-medium">{tripDetails.distance}</p>
                <p className="text-white/80 text-sm">Distance</p>
              </div>
              <div>
                <p className="text-2xl font-medium">{tripDetails.fare}</p>
                <p className="text-white/80 text-sm">Total</p>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Driver Info */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-6 rounded-2xl">
            <div className="flex items-center space-x-4 mb-6">
              <Avatar className="w-16 h-16">
                <AvatarImage src={driver.photo} alt={driver.name} />
                <AvatarFallback>AJ</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h3 className="text-xl">{driver.name}</h3>
                <div className="flex items-center space-x-1">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium">{driver.rating}</span>
                  <span className="text-gray-500">({driver.reviews} trips)</span>
                </div>
                <p className="text-gray-600">{driver.car} • {driver.plate}</p>
              </div>
            </div>

            <h4 className="font-medium mb-3">How was your trip with {driver.name.split(' ')[0]}?</h4>
            
            {/* Star Rating */}
            <div className="flex justify-center space-x-2 mb-6">
              {[1, 2, 3, 4, 5].map((star) => (
                <motion.button
                  key={star}
                  onClick={() => setRating(star)}
                  whileHover={{ scale: 1.1 }}
                  whileTap={{ scale: 0.9 }}
                  className="p-1"
                >
                  <Star
                    className={`w-10 h-10 transition-colors ${
                      star <= rating 
                        ? 'fill-yellow-400 text-yellow-400' 
                        : 'text-gray-300 hover:text-yellow-200'
                    }`}
                  />
                </motion.button>
              ))}
            </div>

            {/* Rating message */}
            {rating > 0 && (
              <motion.div
                initial={{ opacity: 0, y: 10 }}
                animate={{ opacity: 1, y: 0 }}
                className="text-center mb-4"
              >
                <p className="text-gray-600">
                  {rating === 5 && "Excellent! 🌟"}
                  {rating === 4 && "Great trip! 👍"}
                  {rating === 3 && "Good ride 👌"}
                  {rating === 2 && "Could be better 😐"}
                  {rating === 1 && "Not great 😔"}
                </p>
              </motion.div>
            )}
          </Card>
        </motion.div>

        {/* Feedback Tags */}
        {rating >= 4 && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.3 }}
          >
            <Card className="p-6 rounded-2xl">
              <h4 className="font-medium mb-3">What went well?</h4>
              <div className="flex flex-wrap gap-2">
                {feedbackTags.map((tag) => (
                  <motion.button
                    key={tag}
                    onClick={() => handleTagToggle(tag)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`px-3 py-2 rounded-full text-sm transition-all ${
                      selectedTags.includes(tag)
                        ? 'gradient-shuvr text-white'
                        : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                    }`}
                  >
                    {tag}
                  </motion.button>
                ))}
              </div>
            </Card>
          </motion.div>
        )}

        {/* Additional Feedback */}
        {rating > 0 && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.4 }}
          >
            <Card className="p-6 rounded-2xl">
              <h4 className="font-medium mb-3">
                {rating >= 4 ? 'Additional compliments?' : 'How can we improve?'}
              </h4>
              <Textarea
                placeholder={rating >= 4 ? 'Share what made this trip special...' : 'Let us know what went wrong...'}
                value={feedback}
                onChange={(e) => setFeedback(e.target.value)}
                className="w-full rounded-xl border-2 border-gray-200 focus:border-[#5C2E91]"
                rows={3}
              />
            </Card>
          </motion.div>
        )}

        {/* Tip Option */}
        {rating >= 4 && (
          <motion.div
            initial={{ y: 50, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            transition={{ delay: 0.5 }}
          >
            <Card className="p-6 rounded-2xl">
              <div className="flex items-center space-x-2 mb-3">
                <DollarSign className="w-5 h-5 text-green-600" />
                <h4 className="font-medium">Add a tip?</h4>
              </div>
              <p className="text-sm text-gray-600 mb-4">
                Show your appreciation for great service
              </p>
              <div className="flex space-x-3">
                {tipOptions.map((amount) => (
                  <motion.button
                    key={amount}
                    onClick={() => setTip(tip === amount ? '' : amount)}
                    whileHover={{ scale: 1.05 }}
                    whileTap={{ scale: 0.95 }}
                    className={`flex-1 py-3 rounded-xl border-2 transition-all ${
                      tip === amount
                        ? 'border-green-500 bg-green-50 text-green-700'
                        : 'border-gray-200 hover:border-gray-300'
                    }`}
                  >
                    {amount}
                  </motion.button>
                ))}
              </div>
            </Card>
          </motion.div>
        )}
      </div>

      {/* Submit Button */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.6 }}
        className="p-6 border-t border-gray-100"
      >
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button
            onClick={handleSubmit}
            disabled={rating === 0}
            className={`w-full py-4 rounded-xl ${
              rating > 0 
                ? 'gradient-shuvr text-white glow-purple' 
                : 'bg-gray-200 text-gray-500'
            }`}
          >
            {rating > 0 ? 'Submit Rating' : 'Please rate your trip'}
          </Button>
        </motion.div>
        
        <Button
          variant="ghost"
          onClick={onSkip}
          className="w-full mt-2 text-gray-500"
        >
          Skip for now
        </Button>
      </motion.div>
    </div>
  );
};

export default TripRatingScreen;