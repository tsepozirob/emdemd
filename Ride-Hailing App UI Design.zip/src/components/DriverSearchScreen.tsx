import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { X, Car, Users, Zap } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';

interface DriverSearchScreenProps {
  rideType: string;
  pickup: string;
  destination: string;
  estimatedFare: string;
  onDriverFound: (driver: any) => void;
  onCancel: () => void;
}

const DriverSearchScreen: React.FC<DriverSearchScreenProps> = ({
  rideType,
  pickup,
  destination,
  estimatedFare,
  onDriverFound,
  onCancel
}) => {
  const [searchPhase, setSearchPhase] = useState<'searching' | 'found' | 'accepted'>('searching');
  const [searchTime, setSearchTime] = useState(0);

  useEffect(() => {
    const timer = setInterval(() => {
      setSearchTime(prev => prev + 1);
    }, 1000);

    // Simulate driver search phases
    const searchTimer = setTimeout(() => {
      setSearchPhase('found');
    }, 3000);

    const acceptTimer = setTimeout(() => {
      setSearchPhase('accepted');
      // Simulate driver data
      const driverData = {
        name: "Alex Johnson",
        rating: 4.9,
        reviews: 342,
        car: "Toyota Camry",
        color: "Silver", 
        plate: "ABC-123",
        photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
        eta: "3 min",
        phone: "+1 234-567-8900"
      };
      
      setTimeout(() => {
        onDriverFound(driverData);
      }, 2000);
    }, 6000);

    return () => {
      clearInterval(timer);
      clearTimeout(searchTimer);
      clearTimeout(acceptTimer);
    };
  }, [onDriverFound]);

  const getRideIcon = () => {
    switch (rideType) {
      case 'Economy': return <Car className="w-8 h-8" />;
      case 'Premium': return <Car className="w-8 h-8" />;
      case 'Moto': return <Zap className="w-8 h-8" />;
      case 'Carpool': return <Users className="w-8 h-8" />;
      default: return <Car className="w-8 h-8" />;
    }
  };

  const getSearchMessage = () => {
    switch (searchPhase) {
      case 'searching':
        return searchTime < 10 
          ? 'Looking for nearby drivers...' 
          : 'Still searching for drivers in your area...';
      case 'found':
        return 'Driver found! Waiting for confirmation...';
      case 'accepted':
        return 'Driver accepted your request!';
      default:
        return 'Searching for drivers...';
    }
  };

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex items-center justify-between p-4 border-b border-gray-100"
      >
        <h1 className="text-lg gradient-text">Finding Your Driver</h1>
        <Button variant="ghost" onClick={onCancel} className="w-10 h-10 rounded-full">
          <X className="w-5 h-5" />
        </Button>
      </motion.div>

      {/* Main Content */}
      <div className="flex-1 flex flex-col items-center justify-center p-8">
        {/* Animated Search Circle */}
        <motion.div
          className="relative mb-8"
          initial={{ scale: 0.8, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
        >
          <motion.div
            className="w-32 h-32 rounded-full border-4 border-gray-200 relative"
            animate={{
              rotate: searchPhase === 'searching' ? 360 : 0
            }}
            transition={{
              duration: 2,
              repeat: searchPhase === 'searching' ? Infinity : 0,
              ease: "linear"
            }}
          >
            {/* Animated border segments */}
            <motion.div
              className="absolute inset-0 rounded-full"
              style={{
                background: `conic-gradient(from 0deg, transparent 0deg, ${
                  searchPhase === 'searching' ? '#5C2E91' : 
                  searchPhase === 'found' ? '#21D4FD' : '#10B981'
                } 120deg, transparent 240deg)`
              }}
              animate={{
                rotate: searchPhase === 'searching' ? [0, 360] : 0
              }}
              transition={{
                duration: 1.5,
                repeat: searchPhase === 'searching' ? Infinity : 0,
                ease: "linear"
              }}
            />
            
            {/* Center icon */}
            <div className={`absolute inset-4 rounded-full flex items-center justify-center text-white ${
              searchPhase === 'searching' ? 'bg-[#5C2E91]' :
              searchPhase === 'found' ? 'bg-[#21D4FD]' : 'bg-green-500'
            }`}>
              {getRideIcon()}
            </div>
          </motion.div>

          {/* Pulse animation for searching */}
          {searchPhase === 'searching' && (
            <>
              <motion.div
                className="absolute inset-0 w-32 h-32 rounded-full bg-purple-500 opacity-20"
                animate={{
                  scale: [1, 1.5],
                  opacity: [0.2, 0]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeOut"
                }}
              />
              <motion.div
                className="absolute inset-0 w-32 h-32 rounded-full bg-purple-500 opacity-20"
                animate={{
                  scale: [1, 1.8],
                  opacity: [0.2, 0]
                }}
                transition={{
                  duration: 2,
                  repeat: Infinity,
                  ease: "easeOut",
                  delay: 0.5
                }}
              />
            </>
          )}
        </motion.div>

        {/* Status Message */}
        <motion.div
          className="text-center mb-8"
          key={searchPhase}
          initial={{ y: 20, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
        >
          <h2 className="text-2xl mb-2 gradient-text">
            {searchPhase === 'searching' && 'Searching for Drivers'}
            {searchPhase === 'found' && 'Driver Found!'}
            {searchPhase === 'accepted' && 'Request Accepted!'}
          </h2>
          <p className="text-gray-600">{getSearchMessage()}</p>
          <p className="text-sm text-gray-500 mt-2">
            Search time: {Math.floor(searchTime / 60)}:{(searchTime % 60).toString().padStart(2, '0')}
          </p>
        </motion.div>

        {/* Trip Info Card */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
          className="w-full max-w-md"
        >
          <Card className="p-6 glass-dark shadow-xl rounded-2xl">
            <div className="space-y-4">
              <div className="flex items-center justify-between">
                <h3 className="font-medium">{rideType}</h3>
                <span className="text-lg font-medium">{estimatedFare}</span>
              </div>
              
              <div className="space-y-3">
                <div className="flex items-start space-x-3">
                  <div className="w-3 h-3 bg-green-500 rounded-full mt-2"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-500">Pickup</p>
                    <p className="text-sm font-medium">{pickup}</p>
                  </div>
                </div>
                <div className="ml-1.5 h-4 w-px bg-gray-300"></div>
                <div className="flex items-start space-x-3">
                  <div className="w-3 h-3 bg-red-500 rounded-full mt-2"></div>
                  <div className="flex-1">
                    <p className="text-sm text-gray-500">Destination</p>
                    <p className="text-sm font-medium">{destination}</p>
                  </div>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Cancel Request Button */}
        <motion.div
          className="mt-8"
          initial={{ opacity: 0 }}
          animate={{ opacity: 1 }}
          transition={{ delay: 0.5 }}
        >
          <Button
            variant="outline"
            onClick={onCancel}
            className="px-8 py-3 rounded-xl border-2 border-gray-300 hover:bg-gray-50"
          >
            Cancel Request
          </Button>
        </motion.div>

        {/* Tips for faster pickup (show after 15 seconds) */}
        {searchTime > 15 && searchPhase === 'searching' && (
          <motion.div
            initial={{ y: 20, opacity: 0 }}
            animate={{ y: 0, opacity: 1 }}
            className="mt-6 p-4 bg-blue-50 rounded-xl max-w-md"
          >
            <p className="text-sm text-blue-800 text-center">
              💡 Tip: Try moving to a main road or well-lit area for faster pickup
            </p>
          </motion.div>
        )}
      </div>
    </div>
  );
};

export default DriverSearchScreen;