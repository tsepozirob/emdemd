import React, { useState, useEffect } from 'react';
import { motion } from 'motion/react';
import { Phone, MessageCircle, Share2, AlertTriangle, Navigation, Clock, MapPin } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';

interface LiveTrackingScreenProps {
  driver: any;
  pickup: string;
  destination: string;
  onComplete: () => void;
}

const LiveTrackingScreen: React.FC<LiveTrackingScreenProps> = ({ 
  driver, 
  pickup, 
  destination, 
  onComplete 
}) => {
  const [eta, setEta] = useState(3);
  const [driverDistance, setDriverDistance] = useState(0.8);

  useEffect(() => {
    const interval = setInterval(() => {
      setEta(prev => Math.max(0, prev - 0.1));
      setDriverDistance(prev => Math.max(0, prev - 0.1));
    }, 1000);

    // Auto complete after 10 seconds for demo
    const timeout = setTimeout(onComplete, 10000);

    return () => {
      clearInterval(interval);
      clearTimeout(timeout);
    };
  }, [onComplete]);

  return (
    <div className="h-screen relative overflow-hidden bg-gray-100">
      {/* Mock Map with Animated Route */}
      <div className="absolute inset-0 bg-gradient-to-br from-green-100 via-blue-50 to-purple-50">
        {/* Animated route line */}
        <svg className="absolute inset-0 w-full h-full">
          <motion.path
            d="M 100 400 Q 200 300 300 350 T 400 300"
            stroke="#5C2E91"
            strokeWidth="4"
            fill="none"
            strokeDasharray="10,5"
            initial={{ pathLength: 0 }}
            animate={{ pathLength: 1 }}
            transition={{ duration: 2, repeat: Infinity }}
            className="drop-shadow-lg"
          />
        </svg>

        {/* Pickup location */}
        <motion.div
          className="absolute bottom-32 left-16"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-4 h-4 bg-green-500 rounded-full border-4 border-white shadow-lg"></div>
          <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-green-500 text-white px-2 py-1 rounded text-xs whitespace-nowrap">
            Pickup
          </div>
        </motion.div>

        {/* Destination */}
        <motion.div className="absolute top-40 right-16">
          <div className="w-4 h-4 bg-red-500 rounded-full border-4 border-white shadow-lg"></div>
          <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 bg-red-500 text-white px-2 py-1 rounded text-xs whitespace-nowrap">
            Drop-off
          </div>
        </motion.div>

        {/* Moving driver car */}
        <motion.div
          className="absolute"
          animate={{
            x: [120, 220, 320, 400],
            y: [420, 320, 370, 320]
          }}
          transition={{
            duration: 8,
            repeat: Infinity,
            ease: "linear"
          }}
        >
          <div className="w-8 h-8 bg-[#5C2E91] rounded-lg flex items-center justify-center shadow-lg">
            <Navigation className="w-4 h-4 text-white" />
          </div>
        </motion.div>
      </div>

      {/* Driver Info Card */}
      <motion.div
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="absolute top-4 left-4 right-4 z-10"
      >
        <Card className="glass p-4 shadow-xl rounded-2xl">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-3">
              <Avatar className="w-12 h-12">
                <AvatarImage src={driver?.photo} alt={driver?.name} />
                <AvatarFallback>AJ</AvatarFallback>
              </Avatar>
              <div>
                <h3 className="font-medium">{driver?.name}</h3>
                <p className="text-sm text-gray-600">{driver?.car} • {driver?.plate}</p>
              </div>
            </div>
            <div className="flex space-x-2">
              <Button size="sm" variant="outline" className="w-10 h-10 rounded-full">
                <Phone className="w-4 h-4" />
              </Button>
              <Button size="sm" variant="outline" className="w-10 h-10 rounded-full">
                <MessageCircle className="w-4 h-4" />
              </Button>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* ETA Card */}
      <motion.div
        className="absolute top-28 left-4 right-4 z-10"
        animate={{ 
          scale: [1, 1.05, 1],
        }}
        transition={{ duration: 2, repeat: Infinity }}
      >
        <Card className="gradient-shuvr p-4 rounded-2xl shadow-xl">
          <div className="flex items-center justify-between text-white">
            <div className="flex items-center space-x-3">
              <motion.div
                animate={{ rotate: 360 }}
                transition={{ duration: 2, repeat: Infinity, ease: "linear" }}
              >
                <Clock className="w-6 h-6" />
              </motion.div>
              <div>
                <p className="text-sm opacity-90">Driver arriving in</p>
                <p className="text-2xl font-medium">{eta.toFixed(1)} min</p>
              </div>
            </div>
            <div className="text-right">
              <p className="text-sm opacity-90">{driverDistance.toFixed(1)} km away</p>
              <motion.div
                className="w-16 h-2 bg-white/30 rounded-full mt-1"
                initial={{ width: 64 }}
              >
                <motion.div
                  className="h-full bg-white rounded-full"
                  animate={{ width: `${(1 - driverDistance / 0.8) * 100}%` }}
                  transition={{ duration: 0.5 }}
                />
              </motion.div>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Safety & Actions */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.3 }}
        className="absolute bottom-6 left-4 right-4 z-10"
      >
        <Card className="glass p-4 rounded-2xl shadow-xl">
          <div className="flex items-center justify-between">
            <div className="flex space-x-4">
              <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1 rounded-xl border-green-200 hover:bg-green-50"
                >
                  <Share2 className="w-4 h-4 mr-2 text-green-600" />
                  Share Trip
                </Button>
              </motion.div>
              
              <motion.div whileHover={{ scale: 1.1 }} whileTap={{ scale: 0.9 }}>
                <Button 
                  variant="outline" 
                  size="sm" 
                  className="flex-1 rounded-xl border-orange-200 hover:bg-orange-50"
                >
                  <AlertTriangle className="w-4 h-4 mr-2 text-orange-600" />
                  Emergency
                </Button>
              </motion.div>
            </div>
          </div>
          
          <div className="mt-4 p-3 bg-blue-50 rounded-xl">
            <div className="flex items-start space-x-2">
              <MapPin className="w-4 h-4 text-blue-600 mt-0.5" />
              <div className="text-sm">
                <p className="text-blue-800 font-medium">Driver is approaching your pickup location</p>
                <p className="text-blue-600">Look for a {driver?.color} {driver?.car} ({driver?.plate})</p>
              </div>
            </div>
          </div>
        </Card>
      </motion.div>

      {/* Pulse animation overlay for when driver is very close */}
      {eta < 1 && (
        <motion.div
          className="absolute inset-0 bg-purple-500/10 pointer-events-none"
          animate={{ opacity: [0, 0.3, 0] }}
          transition={{ duration: 1, repeat: Infinity }}
        />
      )}
    </div>
  );
};

export default LiveTrackingScreen;