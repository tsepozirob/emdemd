import React, { useState } from "react";
import { motion } from "motion/react";
import {
  Search,
  MapPin,
  Car,
  Users,
  Zap,
  DollarSign,
  MoreHorizontal,
  Navigation,
} from "lucide-react";
import { Button } from "./ui/button";
import { Input } from "./ui/input";
import { Card } from "./ui/card";

interface HomeMapScreenProps {
  onLocationSearch?: () => void;
  onRideSelect?: (rideType: string) => void;
  pickup?: string;
  destination?: string;
  showRideOptions?: boolean;
}

const HomeMapScreen: React.FC<HomeMapScreenProps> = ({
  onLocationSearch,
  onRideSelect,
  pickup = "",
  destination = "",
  showRideOptions = false,
}) => {
  const [showBottomSheet, setShowBottomSheet] =
    useState(showRideOptions);
  const [selectedRide, setSelectedRide] = useState("Economy");

  const rideTypes = [
    {
      name: "Economy",
      icon: <Car className="w-6 h-6" />,
      time: "2 min",
      price: "$12",
      description: "Affordable rides for everyday trips",
    },
    {
      name: "Premium",
      icon: <Car className="w-6 h-6" />,
      time: "3 min",
      price: "$18",
      description: "Comfortable rides in premium vehicles",
    },
    {
      name: "Moto",
      icon: <Zap className="w-6 h-6" />,
      time: "1 min",
      price: "$8",
      description: "Quick motorcycle rides",
    },
    {
      name: "Carpool",
      icon: <Users className="w-6 h-6" />,
      time: "5 min",
      price: "$6",
      description: "Share rides, save money",
    },
  ];

  return (
    <div className="h-screen relative overflow-hidden bg-gray-100">
      {/* Mock Map Background */}
      <div className="absolute inset-0 bg-gradient-to-br from-green-100 via-blue-50 to-purple-50">
        {/* Mock map elements */}
        <div className="absolute top-20 left-10 w-2 h-2 bg-blue-500 rounded-full animate-pulse"></div>
        <div className="absolute top-40 right-20 w-2 h-2 bg-green-500 rounded-full animate-pulse"></div>
        <div className="absolute bottom-80 left-20 w-2 h-2 bg-purple-500 rounded-full animate-pulse"></div>

        {/* Mock roads */}
        <div className="absolute top-32 left-0 w-full h-1 bg-gray-300 opacity-60 rotate-12"></div>
        <div className="absolute top-64 left-0 w-full h-1 bg-gray-300 opacity-60 -rotate-6"></div>

        {/* User location marker */}
        <motion.div
          className="absolute top-1/2 left-1/2 transform -translate-x-1/2 -translate-y-1/2"
          animate={{ scale: [1, 1.1, 1] }}
          transition={{ duration: 2, repeat: Infinity }}
        >
          <div className="w-4 h-4 bg-blue-500 rounded-full border-4 border-white shadow-lg"></div>
          <div className="absolute inset-0 w-4 h-4 bg-blue-500 rounded-full animate-ping opacity-75"></div>
        </motion.div>
      </div>

      {/* Top Search Bar */}
      <motion.div
        initial={{ y: -100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="absolute top-12 left-4 right-4 z-10"
      >
        <div className="glass rounded-2xl p-4 shadow-xl">
          {!showRideOptions ? (
            <div
              className="flex items-center space-x-3 cursor-pointer"
              onClick={onLocationSearch}
            >
              <Search className="w-5 h-5 text-gray-500" />
              <div className="border-none bg-transparent text-lg placeholder-gray-500 focus:ring-0 py-2">
                Where to?
              </div>
            </div>
          ) : (
            <div className="space-y-3">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm text-gray-500">From</p>
                  <p className="font-medium truncate">
                    {pickup}
                  </p>
                </div>
              </div>
              <div className="ml-1.5 h-4 w-px bg-gray-300"></div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm text-gray-500">To</p>
                  <p className="font-medium truncate">
                    {destination}
                  </p>
                </div>
              </div>
            </div>
          )}
        </div>
      </motion.div>

      {/* Location Button */}
      <motion.div
        className="absolute top-32 right-4 z-10"
        whileHover={{ scale: 1.1 }}
        whileTap={{ scale: 0.9 }}
      >
        <Button className="w-12 h-12 rounded-full glass shadow-lg border-white/30 hover:bg-white/20">
          <Navigation className="w-5 h-5 text-gray-700" />
        </Button>
      </motion.div>

      {/* Bottom Sheet - Only show when ride options are available */}
      {showRideOptions && (
        <motion.div
          initial={{ y: 300 }}
          animate={{ y: showBottomSheet ? 0 : 250 }}
          drag="y"
          dragConstraints={{ top: 0, bottom: 250 }}
          onDragEnd={(_, info) => {
            if (info.offset.y > 100) {
              setShowBottomSheet(false);
            } else {
              setShowBottomSheet(true);
            }
          }}
          className="absolute bottom-0 left-0 right-0 z-20"
        >
          <div className="bg-white rounded-t-3xl shadow-2xl">
            {/* Drag Handle */}
            <div className="flex justify-center pt-4 pb-2">
              <div className="w-12 h-1 bg-gray-300 rounded-full"></div>
            </div>

            <div className="p-6">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-xl gradient-text">
                  Choose your ride
                </h3>
                <Button variant="ghost" size="sm">
                  <MoreHorizontal className="w-5 h-5" />
                </Button>
              </div>

              {/* Ride Options */}
              <div className="space-y-3">
                {rideTypes.map((ride) => (
                  <motion.div
                    key={ride.name}
                    whileHover={{ scale: 1.02 }}
                    whileTap={{ scale: 0.98 }}
                  >
                    <Card
                      className={`p-4 cursor-pointer transition-all duration-200 ${
                        selectedRide === ride.name
                          ? "ring-2 ring-[#5C2E91] bg-purple-50"
                          : "hover:bg-gray-50"
                      }`}
                      onClick={() => setSelectedRide(ride.name)}
                    >
                      <div className="flex items-center justify-between">
                        <div className="flex items-center space-x-4">
                          <div
                            className={`p-3 rounded-xl ${
                              selectedRide === ride.name
                                ? "gradient-shuvr text-white"
                                : "bg-gray-100 text-gray-600"
                            }`}
                          >
                            {ride.icon}
                          </div>
                          <div>
                            <div className="flex items-center space-x-2">
                              <h4 className="font-medium">
                                {ride.name}
                              </h4>
                              <span className="text-sm text-gray-500">
                                {ride.time}
                              </span>
                            </div>
                            <p className="text-sm text-gray-500">
                              {ride.description}
                            </p>
                          </div>
                        </div>
                        <div className="text-right">
                          <div className="text-lg font-medium">
                            {ride.price}
                          </div>
                        </div>
                      </div>
                    </Card>
                  </motion.div>
                ))}
              </div>

              {/* Confirm Button */}
              <motion.div
                className="mt-6"
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Button
                  onClick={() => onRideSelect?.(selectedRide)}
                  className="w-full gradient-shuvr text-white py-4 rounded-xl glow-purple"
                >
                  Request {selectedRide}
                  <Car className="ml-2 w-5 h-5" />
                </Button>
              </motion.div>
            </div>
          </div>
        </motion.div>
      )}
    </div>
  );
};

export default HomeMapScreen;