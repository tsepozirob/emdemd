import React, { useState } from 'react';
import { motion } from 'motion/react';
import { MapPin, Search, Clock, Star, ArrowLeft, Navigation } from 'lucide-react';
import { Button } from './ui/button';
import { Input } from './ui/input';
import { Card } from './ui/card';

interface LocationSelectionScreenProps {
  onLocationsSet: (pickup: string, destination: string) => void;
  onBack: () => void;
}

const LocationSelectionScreen: React.FC<LocationSelectionScreenProps> = ({ 
  onLocationsSet, 
  onBack 
}) => {
  const [pickup, setPickup] = useState('');
  const [destination, setDestination] = useState('');
  const [currentInput, setCurrentInput] = useState<'pickup' | 'destination'>('pickup');

  const recentPlaces = [
    { name: 'Home', address: '123 Main Street, Downtown', icon: '🏠' },
    { name: 'Work', address: '456 Business Blvd, Office District', icon: '🏢' },
    { name: 'Airport', address: 'International Airport Terminal 1', icon: '✈️' },
    { name: 'Shopping Mall', address: '789 Commerce Ave, Shopping District', icon: '🛍️' }
  ];

  const suggestions = [
    '123 Main Street, Downtown',
    '456 Oak Avenue, Uptown', 
    '789 Pine Road, Midtown',
    '321 Elm Street, Suburbs',
    'Central Park, City Center',
    'University Campus, Education District'
  ];

  const handlePlaceSelect = (address: string) => {
    if (currentInput === 'pickup') {
      setPickup(address);
      setCurrentInput('destination');
    } else {
      setDestination(address);
    }
  };

  const handleContinue = () => {
    if (pickup && destination) {
      onLocationsSet(pickup, destination);
    }
  };

  const handleUseCurrentLocation = () => {
    const currentLocation = 'Current Location - 123 Main Street, Downtown';
    if (currentInput === 'pickup') {
      setPickup(currentLocation);
      setCurrentInput('destination');
    } else {
      setDestination(currentLocation);
    }
  };

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex items-center justify-between p-4 border-b border-gray-100"
      >
        <Button variant="ghost" onClick={onBack} className="w-10 h-10 rounded-full">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg gradient-text">Set Location</h1>
        <div className="w-10"></div>
      </motion.div>

      {/* Location Inputs */}
      <motion.div
        initial={{ y: 50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.1 }}
        className="p-4 border-b border-gray-100"
      >
        <div className="space-y-4">
          {/* Pickup Input */}
          <div className="relative">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-green-500 rounded-full"></div>
              <div className="flex-1">
                <Input
                  placeholder="Pickup location"
                  value={pickup}
                  onChange={(e) => setPickup(e.target.value)}
                  onFocus={() => setCurrentInput('pickup')}
                  className={`w-full px-4 py-3 rounded-xl border-2 transition-all ${
                    currentInput === 'pickup' 
                      ? 'border-[#5C2E91] bg-purple-50' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>
            </div>
          </div>

          {/* Connector Line */}
          <div className="ml-1.5 h-6 w-px bg-gray-300"></div>

          {/* Destination Input */}
          <div className="relative">
            <div className="flex items-center space-x-3">
              <div className="w-3 h-3 bg-red-500 rounded-full"></div>
              <div className="flex-1">
                <Input
                  placeholder="Where to?"
                  value={destination}
                  onChange={(e) => setDestination(e.target.value)}
                  onFocus={() => setCurrentInput('destination')}
                  className={`w-full px-4 py-3 rounded-xl border-2 transition-all ${
                    currentInput === 'destination' 
                      ? 'border-[#5C2E91] bg-purple-50' 
                      : 'border-gray-200 bg-gray-50'
                  }`}
                />
              </div>
            </div>
          </div>
        </div>

        {/* Use Current Location Button */}
        <motion.div
          className="mt-4"
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button
            variant="outline"
            onClick={handleUseCurrentLocation}
            className="w-full rounded-xl border-2 border-blue-200 hover:bg-blue-50 flex items-center justify-center space-x-2"
          >
            <Navigation className="w-4 h-4 text-blue-600" />
            <span>Use Current Location</span>
          </Button>
        </motion.div>
      </motion.div>

      {/* Content Area */}
      <div className="flex-1 overflow-y-auto">
        {/* Recent Places */}
        <div className="p-4">
          <h3 className="text-sm font-medium text-gray-500 mb-3 uppercase tracking-wide">
            Recent Places
          </h3>
          <div className="space-y-2">
            {recentPlaces.map((place, index) => (
              <motion.div
                key={place.name}
                initial={{ x: -50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: index * 0.1 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <Card 
                  className="p-4 cursor-pointer hover:bg-gray-50 transition-colors"
                  onClick={() => handlePlaceSelect(place.address)}
                >
                  <div className="flex items-center space-x-3">
                    <div className="text-2xl">{place.icon}</div>
                    <div className="flex-1">
                      <h4 className="font-medium">{place.name}</h4>
                      <p className="text-sm text-gray-500">{place.address}</p>
                    </div>
                    <Clock className="w-4 h-4 text-gray-400" />
                  </div>
                </Card>
              </motion.div>
            ))}
          </div>
        </div>

        {/* Suggestions */}
        <div className="p-4 border-t border-gray-100">
          <h3 className="text-sm font-medium text-gray-500 mb-3 uppercase tracking-wide">
            Suggestions
          </h3>
          <div className="space-y-2">
            {suggestions.map((suggestion, index) => (
              <motion.div
                key={suggestion}
                initial={{ x: -50, opacity: 0 }}
                animate={{ x: 0, opacity: 1 }}
                transition={{ delay: 0.4 + index * 0.05 }}
                whileHover={{ scale: 1.02 }}
                whileTap={{ scale: 0.98 }}
              >
                <div 
                  className="flex items-center space-x-3 p-3 rounded-xl hover:bg-gray-50 cursor-pointer transition-colors"
                  onClick={() => handlePlaceSelect(suggestion)}
                >
                  <MapPin className="w-5 h-5 text-gray-400" />
                  <span className="text-gray-700">{suggestion}</span>
                </div>
              </motion.div>
            ))}
          </div>
        </div>
      </div>

      {/* Continue Button */}
      {pickup && destination && (
        <motion.div
          initial={{ y: 100, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          className="p-4 border-t border-gray-100"
        >
          <motion.div
            whileHover={{ scale: 1.02 }}
            whileTap={{ scale: 0.98 }}
          >
            <Button
              onClick={handleContinue}
              className="w-full gradient-shuvr text-white py-4 rounded-xl glow-purple"
            >
              Confirm Locations
            </Button>
          </motion.div>
        </motion.div>
      )}
    </div>
  );
};

export default LocationSelectionScreen;