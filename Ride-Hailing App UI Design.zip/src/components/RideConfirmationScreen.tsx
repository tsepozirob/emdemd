import React from 'react';
import { motion } from 'motion/react';
import { Star, MapPin, CreditCard, Clock, Phone, MessageCircle, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Avatar, AvatarImage, AvatarFallback } from './ui/avatar';

interface RideConfirmationScreenProps {
  rideType: string;
  pickup: string;
  destination: string;
  fare: string;
  onConfirm: () => void;
  onBack: () => void;
}

const RideConfirmationScreen: React.FC<RideConfirmationScreenProps> = ({ 
  rideType, 
  pickup,
  destination,
  fare,
  onConfirm, 
  onBack 
}) => {
  const driverData = {
    name: "Alex Johnson",
    rating: 4.9,
    reviews: 342,
    car: "Toyota Camry",
    color: "Silver",
    plate: "ABC-123",
    photo: "https://images.unsplash.com/photo-1507003211169-0a1dd7228f2d?w=150&h=150&fit=crop&crop=face",
    eta: "3 min",
    fare: fare
  };

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex items-center justify-between p-4 border-b border-gray-100"
      >
        <Button variant="ghost" onClick={onBack} className="w-10 h-10 rounded-full">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg gradient-text">Confirm Your Ride</h1>
        <div className="w-10"></div>
      </motion.div>

      {/* Content */}
      <div className="flex-1 p-6 space-y-6">
        {/* Driver Info Card */}
        <motion.div
          initial={{ scale: 0.9, opacity: 0 }}
          animate={{ scale: 1, opacity: 1 }}
          transition={{ delay: 0.1 }}
        >
          <Card className="p-6 glass-dark shadow-xl rounded-2xl">
            <div className="flex items-center space-x-4 mb-4">
              <Avatar className="w-16 h-16">
                <AvatarImage src={driverData.photo} alt={driverData.name} />
                <AvatarFallback>AJ</AvatarFallback>
              </Avatar>
              <div className="flex-1">
                <h3 className="text-xl mb-1">{driverData.name}</h3>
                <div className="flex items-center space-x-1 mb-2">
                  <Star className="w-4 h-4 fill-yellow-400 text-yellow-400" />
                  <span className="font-medium">{driverData.rating}</span>
                  <span className="text-gray-500">({driverData.reviews} rides)</span>
                </div>
                <div className="flex items-center space-x-4 text-sm text-gray-600">
                  <span>{driverData.car}</span>
                  <span>•</span>
                  <span>{driverData.color}</span>
                  <span>•</span>
                  <span className="font-medium">{driverData.plate}</span>
                </div>
              </div>
              <div className="flex space-x-2">
                <Button size="sm" variant="outline" className="w-10 h-10 rounded-full">
                  <Phone className="w-4 h-4" />
                </Button>
                <Button size="sm" variant="outline" className="w-10 h-10 rounded-full">
                  <MessageCircle className="w-4 h-4" />
                </Button>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Trip Details */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.2 }}
        >
          <Card className="p-6 rounded-2xl">
            <h3 className="text-lg mb-4 gradient-text">Trip Details</h3>
            <div className="space-y-4">
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-green-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm text-gray-500">Pickup Location</p>
                  <p className="font-medium">{pickup}</p>
                </div>
              </div>
              <div className="ml-1.5 h-8 w-px bg-gray-300"></div>
              <div className="flex items-center space-x-3">
                <div className="w-3 h-3 bg-red-500 rounded-full"></div>
                <div className="flex-1">
                  <p className="text-sm text-gray-500">Destination</p>
                  <p className="font-medium">{destination}</p>
                </div>
              </div>
            </div>
          </Card>
        </motion.div>

        {/* Fare & Payment */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.3 }}
        >
          <Card className="p-6 rounded-2xl">
            <div className="flex items-center justify-between mb-4">
              <h3 className="text-lg gradient-text">Fare Estimate</h3>
              <div className="text-2xl font-medium">{driverData.fare}</div>
            </div>
            
            <div className="space-y-3 mb-4">
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Base Fare</span>
                <span>$8.00</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Distance (2.3 km)</span>
                <span>$3.50</span>
              </div>
              <div className="flex justify-between text-sm">
                <span className="text-gray-600">Service Fee</span>
                <span>$0.50</span>
              </div>
              <div className="border-t pt-2 flex justify-between font-medium">
                <span>Total</span>
                <span>{driverData.fare}</span>
              </div>
            </div>

            <div className="flex items-center justify-between p-3 bg-gray-50 rounded-xl">
              <div className="flex items-center space-x-3">
                <CreditCard className="w-5 h-5 text-gray-600" />
                <span>Visa •••• 4567</span>
              </div>
              <Button variant="ghost" size="sm" className="text-[#5C2E91]">
                Change
              </Button>
            </div>
          </Card>
        </motion.div>

        {/* ETA */}
        <motion.div
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: 0.4 }}
        >
          <Card className="p-4 rounded-2xl bg-gradient-to-r from-purple-50 to-teal-50 border-purple-200">
            <div className="flex items-center space-x-3">
              <div className="glass rounded-full p-3">
                <Clock className="w-5 h-5 text-[#5C2E91]" />
              </div>
              <div>
                <p className="text-sm text-gray-600">Driver arriving in</p>
                <p className="text-lg font-medium">{driverData.eta}</p>
              </div>
            </div>
          </Card>
        </motion.div>
      </div>

      {/* Confirm Button */}
      <motion.div
        initial={{ y: 100, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        transition={{ delay: 0.5 }}
        className="p-6 border-t border-gray-100"
      >
        <motion.div
          whileHover={{ scale: 1.02 }}
          whileTap={{ scale: 0.98 }}
        >
          <Button
            onClick={onConfirm}
            className="w-full gradient-shuvr text-white py-4 rounded-xl glow-purple"
          >
            Confirm Ride
          </Button>
        </motion.div>
        
        <p className="text-center text-sm text-gray-500 mt-3">
          You'll be charged after your trip is completed
        </p>
      </motion.div>
    </div>
  );
};

export default RideConfirmationScreen;