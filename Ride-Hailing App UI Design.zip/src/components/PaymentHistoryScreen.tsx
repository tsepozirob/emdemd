import React, { useState } from 'react';
import { motion } from 'motion/react';
import { CreditCard, Plus, MapPin, Clock, Star, ChevronRight, Wallet, ArrowLeft } from 'lucide-react';
import { Button } from './ui/button';
import { Card } from './ui/card';
import { Tabs, TabsContent, TabsList, TabsTrigger } from './ui/tabs';
import { Badge } from './ui/badge';

interface PaymentHistoryScreenProps {
  onBack: () => void;
}

const PaymentHistoryScreen: React.FC<PaymentHistoryScreenProps> = ({ onBack }) => {
  const [selectedTab, setSelectedTab] = useState('wallet');

  const paymentMethods = [
    {
      id: 1,
      type: 'Visa',
      last4: '4567',
      isDefault: true,
      icon: '💳'
    },
    {
      id: 2,
      type: 'Mastercard',
      last4: '8901',
      isDefault: false,
      icon: '💳'
    },
    {
      id: 3,
      type: 'PayPal',
      email: 'user@email.com',
      isDefault: false,
      icon: '🅿️'
    },
    {
      id: 4,
      type: 'Mobile Money',
      phone: '+1 234-567-8900',
      isDefault: false,
      icon: '📱'
    }
  ];

  const tripHistory = [
    {
      id: 1,
      date: 'Today, 2:30 PM',
      from: '123 Main Street',
      to: '456 Oak Avenue',
      fare: '$12.50',
      status: 'completed',
      rating: 5,
      driver: 'Alex Johnson',
      mapThumbnail: 'https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?w=100&h=100&fit=crop'
    },
    {
      id: 2,
      date: 'Yesterday, 9:15 AM',
      from: '789 Pine Road',
      to: '321 Elm Street',
      fare: '$8.75',
      status: 'completed',
      rating: 4,
      driver: 'Sarah Chen',
      mapThumbnail: 'https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?w=100&h=100&fit=crop'
    },
    {
      id: 3,
      date: 'Oct 12, 6:45 PM',
      from: 'Airport Terminal 1',
      to: 'Downtown Hotel',
      fare: '$24.00',
      status: 'completed',
      rating: 5,
      driver: 'Mike Rodriguez',
      mapThumbnail: 'https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?w=100&h=100&fit=crop'
    },
    {
      id: 4,
      date: 'Oct 10, 3:20 PM',
      from: 'Shopping Mall',
      to: 'Home',
      fare: '$15.25',
      status: 'cancelled',
      rating: null,
      driver: null,
      mapThumbnail: 'https://images.unsplash.com/photo-1569336415962-a4bd9f69cd83?w=100&h=100&fit=crop'
    }
  ];

  const WalletContent = () => (
    <div className="space-y-6">
      {/* Balance Card */}
      <motion.div
        initial={{ scale: 0.9, opacity: 0 }}
        animate={{ scale: 1, opacity: 1 }}
      >
        <Card className="gradient-shuvr p-6 rounded-2xl text-white shadow-xl">
          <div className="flex items-center justify-between mb-4">
            <div className="flex items-center space-x-2">
              <Wallet className="w-6 h-6" />
              <span className="text-lg">Shuvr Wallet</span>
            </div>
            <Badge variant="secondary" className="bg-white/20 text-white">
              Active
            </Badge>
          </div>
          <div className="mb-4">
            <p className="text-sm opacity-90">Available Balance</p>
            <p className="text-3xl font-medium">$45.80</p>
          </div>
          <Button className="w-full bg-white/20 hover:bg-white/30 text-white border-white/30">
            <Plus className="w-4 h-4 mr-2" />
            Add Money
          </Button>
        </Card>
      </motion.div>

      {/* Payment Methods */}
      <div>
        <div className="flex items-center justify-between mb-4">
          <h3 className="text-lg gradient-text">Payment Methods</h3>
          <Button variant="ghost" size="sm" className="text-[#5C2E91]">
            <Plus className="w-4 h-4 mr-1" />
            Add
          </Button>
        </div>
        
        <div className="space-y-3">
          {paymentMethods.map((method, index) => (
            <motion.div
              key={method.id}
              initial={{ x: -50, opacity: 0 }}
              animate={{ x: 0, opacity: 1 }}
              transition={{ delay: index * 0.1 }}
            >
              <Card className="p-4 hover:bg-gray-50 transition-colors cursor-pointer">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className="text-2xl">{method.icon}</div>
                    <div>
                      <div className="flex items-center space-x-2">
                        <span className="font-medium">{method.type}</span>
                        {method.isDefault && (
                          <Badge variant="secondary" className="text-xs">Default</Badge>
                        )}
                      </div>
                      <p className="text-sm text-gray-500">
                        {method.last4 && `•••• ${method.last4}`}
                        {method.email && method.email}
                        {method.phone && method.phone}
                      </p>
                    </div>
                  </div>
                  <ChevronRight className="w-5 h-5 text-gray-400" />
                </div>
              </Card>
            </motion.div>
          ))}
        </div>
      </div>
    </div>
  );

  const HistoryContent = () => (
    <div className="space-y-4">
      {tripHistory.map((trip, index) => (
        <motion.div
          key={trip.id}
          initial={{ y: 50, opacity: 0 }}
          animate={{ y: 0, opacity: 1 }}
          transition={{ delay: index * 0.1 }}
        >
          <Card className="p-4 hover:bg-gray-50 transition-colors cursor-pointer">
            <div className="flex space-x-4">
              {/* Map Thumbnail */}
              <div className="w-16 h-16 rounded-xl overflow-hidden bg-gray-200 flex-shrink-0">
                <img 
                  src={trip.mapThumbnail} 
                  alt="Trip route" 
                  className="w-full h-full object-cover"
                />
              </div>
              
              {/* Trip Details */}
              <div className="flex-1 min-w-0">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Clock className="w-4 h-4 text-gray-500" />
                    <span className="text-sm text-gray-500">{trip.date}</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <span className="font-medium">{trip.fare}</span>
                    <Badge 
                      variant={trip.status === 'completed' ? 'secondary' : 'destructive'}
                      className="text-xs"
                    >
                      {trip.status}
                    </Badge>
                  </div>
                </div>
                
                <div className="space-y-1 mb-2">
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-green-500 rounded-full mt-2"></div>
                    <p className="text-sm text-gray-600 truncate">{trip.from}</p>
                  </div>
                  <div className="ml-1 h-4 w-px bg-gray-300"></div>
                  <div className="flex items-start space-x-2">
                    <div className="w-2 h-2 bg-red-500 rounded-full mt-2"></div>
                    <p className="text-sm text-gray-600 truncate">{trip.to}</p>
                  </div>
                </div>
                
                {trip.status === 'completed' && trip.rating && (
                  <div className="flex items-center space-x-1">
                    <div className="flex">
                      {[...Array(5)].map((_, i) => (
                        <Star
                          key={i}
                          className={`w-3 h-3 ${
                            i < trip.rating ? 'fill-yellow-400 text-yellow-400' : 'text-gray-300'
                          }`}
                        />
                      ))}
                    </div>
                    <span className="text-xs text-gray-500">• {trip.driver}</span>
                  </div>
                )}
              </div>
              
              <ChevronRight className="w-5 h-5 text-gray-400 mt-2" />
            </div>
          </Card>
        </motion.div>
      ))}
    </div>
  );

  return (
    <div className="h-screen bg-white flex flex-col">
      {/* Header */}
      <motion.div
        initial={{ y: -50, opacity: 0 }}
        animate={{ y: 0, opacity: 1 }}
        className="flex items-center justify-between p-4 border-b border-gray-100"
      >
        <Button variant="ghost" onClick={onBack} className="w-10 h-10 rounded-full">
          <ArrowLeft className="w-5 h-5" />
        </Button>
        <h1 className="text-lg gradient-text">Payment & History</h1>
        <div className="w-10"></div>
      </motion.div>

      {/* Content */}
      <div className="flex-1 overflow-hidden">
        <Tabs value={selectedTab} onValueChange={setSelectedTab} className="h-full flex flex-col">
          <TabsList className="grid w-full grid-cols-2 mx-4 mt-4 rounded-xl">
            <TabsTrigger value="wallet" className="rounded-lg">Wallet</TabsTrigger>
            <TabsTrigger value="history" className="rounded-lg">History</TabsTrigger>
          </TabsList>
          
          <div className="flex-1 overflow-y-auto p-4">
            <TabsContent value="wallet" className="mt-0">
              <WalletContent />
            </TabsContent>
            <TabsContent value="history" className="mt-0">
              <HistoryContent />
            </TabsContent>
          </div>
        </Tabs>
      </div>
    </div>
  );
};

export default PaymentHistoryScreen;